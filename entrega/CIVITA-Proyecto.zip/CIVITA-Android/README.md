# CIVITA Android · 1.0.742

Kotlin y Jetpack Compose. Acceso con Google y correo, registro, recuperación y cierre de sesión. Firestore: categorías, configuración, novedades y publicación de texto.

Abre esta carpeta en Android Studio con JDK 21, SDK Android 37.2 y Build Tools 37.0.0. Gradle Wrapper 9.6.0 conserva la verificación SHA-256.

El archivo Firebase incluido es el proporcionado por el usuario; no contiene cliente OAuth. Antes de probar Google debes habilitar Google y Correo/Contraseña, registrar las huellas de tu APK y reemplazar app/google-services.json por el actualizado. Consulta docs/entrega/INICIO-FIREBASE.md.

Consulta docs/entrega/VALIDACION.md para distinguir compilación, pruebas locales, ejecución de la interfaz y operaciones Firebase reales pendientes. No hay datos ficticios de comunidad en la app.

Los diagramas actualizados están en docs/uml (PDF, PNG, SVG y PlantUML); la documentación técnica está en docs/entrega. Los antiguos esquemas de docs/database conservan el diseño previsto, que incluye ampliaciones no implementadas.

By: Joan Erazo v.10742
