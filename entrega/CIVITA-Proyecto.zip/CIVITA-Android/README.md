# CIVITA Android · 1.1.742

Abre esta carpeta (settings.gradle.kts) en Android Studio. Kotlin, Jetpack Compose, Firebase Authentication, Firestore y Cloud Storage.

Requisitos: JDK 21, Android SDK 37.2, Build Tools 37.0.0 y Android Studio compatible con AGP 9.4.0. Gradle Wrapper 9.6.0 incluye checksum SHA-256. Android mínimo API 26.

El ZIP entregado incluye app/google-services.json actualizado del proyecto civita-5cc42 con cliente OAuth web. Registra la SHA de tu firma local si recompilas. El repositorio Git no rastrea ese JSON; conserva el del ZIP o descárgalo de Firebase.

Las reglas ampliadas requieren actualización desde Cloud Shell: consulta firebase/README.md y docs/entrega/ANDROID-STUDIO.md. Ese paso usa tu sesión administrativa; no se incorpora ninguna clave de servidor al proyecto.

Documentación: docs/uml contiene diagramas editables, PNG, SVG y PDF; docs/entrega contiene informe, validación y guía de sustentación. docs/database conserva los MER originales del ZIP. firebase/SCHEMA.md y schema.json describen las 18 rutas documentales del modelo ampliado.

Compilar: ./gradlew testDebugUnitTest assembleDebug lintDebug (Windows: gradlew.bat).
Simulación visual sin Firebase: ./gradlew assembleDebug -PcivitaSimulation=true; applicationId distinto con sufijo .simulation y aviso visible. Recompilar sin esa propiedad para la app conectada.

No se presenta como verificada la autenticación Google real en este emulador sin Play Services ni la publicación de las reglas ampliadas en producción. Las suscripciones guardan preferencias; no hay envío push desplegado. Cloud Storage requiere bucket y reglas operativos para adjuntar evidencias. Ver docs/entrega/VALIDACION.md.

By: Joan Erazo v.10742
