package co.edu.uniautonoma.civita.data

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AppContainer(context: Context) {
    val repository: ReportRepository? = run {
        val app = FirebaseApp.getApps(context).firstOrNull()
            ?: FirebaseApp.initializeApp(context)
        app?.let { FirebaseReportRepository(FirebaseAuth.getInstance(it), FirebaseFirestore.getInstance(it)) }
    }
    val authRepository: AuthRepository? = FirebaseApp.getApps(context).firstOrNull()?.let { AuthRepository(FirebaseAuth.getInstance(it)) }
}
