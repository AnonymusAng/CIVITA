# CIVITA · Activación del acceso real

Versión 1.0.742. Paquete Android: `co.edu.uniautonoma.civita`.
El proyecto incluye el google-services.json que entregaste. Ese archivo no contiene clientes OAuth. El código ya implementa correo y Google, pero el proveedor Google no puede completar el acceso hasta configurar el proyecto Firebase.

## 1. Habilitar correo y Google
En Firebase Console abre Authentication → Comenzar → Método de acceso.
Habilita **Correo electrónico/contraseña** y **Google**. En Google selecciona el correo de soporte del proyecto y guarda. No hace falta habilitar Anónimo para esta versión.

## 2. Registrar las huellas del APK entregado
Configuración del proyecto → Tus apps → aplicación Android con el paquete anterior → Agregar huella digital.
Para el APK debug descargable de esta entrega:

SHA-1: `CF:B0:1B:90:59:57:9B:7B:91:F1:21:89:13:7A:C0:4E:07:88:73:EC`

SHA-256: `9D:15:DA:CB:34:A1:66:15:AF:69:73:F7:67:5C:A9:D3:DD:45:D6:6B:EE:5A:FD:C3:8B:3D:06:7B:7D:75:DC:AD`

Si compilas con tu propia firma, las huellas cambian. Obtén las correspondientes ejecutando `./gradlew :app:signingReport` y registra esas huellas también. La clave de firma de este entorno no se distribuye en el ZIP.

## 3. Actualizar la configuración Android
Después de habilitar Google y agregar SHA, descarga **google-services.json** desde la aplicación Android de Firebase.
Sustituye `app/google-services.json` por ese archivo. Sincroniza y recompila; el plugin genera `default_web_client_id` a partir del cliente OAuth de tipo web. No pegues una API key como client ID y no crees credenciales ficticias.
Prueba Google en un teléfono o emulador con Google Play Services y una cuenta Google. El emulador básico usado aquí no incluye Google Play Services.

## 4. Preparar Firestore
Conserva tus documentos existentes. En `appConfig/public` deben existir:

- allowedMediaTypes: array de String (por ejemplo image/jpeg, image/png, video/mp4).
- maxEvidenceBytes: entero positivo (10485760).
- maxEvidenceCount: entero (3).
- minRadiusMeters: entero positivo (250).
- maxRadiusMeters: entero mayor o igual al mínimo (15000).

En cada documento de `categories`, por ejemplo `movilidad`:

- active: Boolean true.
- name: String, por ejemplo Movilidad.
- color: String hexadecimal #1976D2.
- defaultDurationHours: entero entre 1 y 168, por ejemplo 4.

Los campos adicionales icon, updatedAt y version pueden conservarse. No es necesario crear reportes de prueba manualmente: el formulario crea `reports/{requestId}` con autor y timestamps del servidor.
Revisa el archivo `firestore.rules` y publícalo en la pestaña Reglas de Firestore para permitir las operaciones implementadas. Estas reglas limitan los campos y permiten crear reportes a usuarios autenticados; no habilitan modificación, borrado o moderación desde el cliente.

## 5. Abrir y ejecutar
Abre la carpeta CIVITA-Android en Android Studio, usa JDK 21 e instala SDK Android 37.2 y Build Tools 37.0.0. Sincroniza Gradle y ejecuta en Android 8 o posterior.
El APK entregado se instala directamente; si cambia la configuración Firebase debes recompilar para incorporar el nuevo JSON.

## 6. Demostración de las dos funcionalidades
1. Crea una cuenta con correo y contraseña de al menos 8 caracteres. Comprueba que aparece en Authentication y que la app entra a la pantalla de comunidad. Cierra sesión y prueba el acceso con esa cuenta y la recuperación de contraseña.
2. Abre Nueva novedad, selecciona una categoría activa y publica título, descripción, referencia y afectación. Comprueba confirmación, aparición en Novedades y documento en Firestore con creatorId correcto, estado review y timestamps. Prueba el filtro de categoría.
Finalmente inicia con Google y comprueba que aparece como usuario Google en Authentication.

## Limitación de la verificación desde este entorno
El proxy devuelve HTTP 403 al contactar identitytoolkit.googleapis.com. La descarga del emulador Firestore desde storage.googleapis.com también está denegada. No se ha comprobado autenticación ni lectura/escritura contra tu Firebase real. Compilación, pruebas unitarias y ejecución de la interfaz se registran en VALIDACION.md. Esto no se resuelve cambiando la API key ni ocultando el error.

Para continuar desde este entorno cloud, revisa los dominios de Firebase en los ajustes del entorno. Se guardaron dominios e instrucciones en el borrador; guardarlo no cambia la red de la máquina en ejecución ni publica la configuración. Las pruebas desde tu teléfono usan su conexión habitual.

Si instalaste el APK entregado y después recompilas con una firma diferente, desinstala esa versión antes de instalar la nueva. Esto elimina la sesión y los borradores locales; no borra documentos de Firestore. Registra también las nuevas huellas de firma.
