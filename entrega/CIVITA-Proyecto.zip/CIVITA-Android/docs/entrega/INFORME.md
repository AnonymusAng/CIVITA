# CIVITA · Entrega técnica actualizada

Versión 1.0.742 · Android Studio · Kotlin y Jetpack Compose.
Autoría en la interfaz: By: Joan Erazo v.10742, en cursiva.

## Alcance implementado
Acceso con Google mediante Android Credential Manager y Google ID; acceso y registro con correo/contraseña mediante Firebase Authentication; recuperación de contraseña; restauración de sesión y cierre de sesión. La app requiere una cuenta identificada y ya no inicia usuarios anónimos automáticamente.
La comunidad consulta configuración pública y categorías activas, observa las últimas 100 novedades en Firestore, filtra por categoría y publica novedades de texto con confirmación remota. El mapa es ilustrativo: no representa GPS ni ubicaciones reales de los reportes. No hay carga multimedia, notificaciones push, cálculo de proximidad o moderación implementados.

## Arquitectura y organización conservada
El módulo Gradle :app mantiene MainActivity, data, model, ui/screens, ui/components y ui/theme. Las funciones Compose no se convierten artificialmente en clases de pantalla. MainActivity monta CivitaApp; AppContainer inicializa las dependencias; AuthViewModel representa la sesión y coordina AuthRepository; tras autenticar, CivitaViewModel coordina ReportRepository y su adaptador FirebaseReportRepository.
La UI observa StateFlow con ciclo de vida. Los listeners de Firestore usan callbackFlow y awaitClose. Al salir del área autenticada se cancela la observación; al volver se recarga. Las contraseñas no se guardan en rememberSaveable, archivos o registros. El correo y el modo del formulario sí conservan su estado tras recreación.

## Reglas de negocio y publicación
El formulario valida categoría, longitud de título y descripción, referencia del lugar y severidad 1–3. La categoría tiene que existir y estar activa. El ID de publicación se conserva durante reintentos del mismo borrador para evitar duplicados; la operación es una transacción remota con timestamps de servidor. El estado inicial es review y confidence es 0. Las reglas comprueban autenticación, autor, campos permitidos y datos de categoría. No se publica una novedad como exitosa hasta recibir confirmación del servidor.

## Interfaz
Pantalla inicial con fondo degradado azul/verde, tarjeta de acceso, controles de correo y contraseña, opción Google, registro y recuperación. La firma solicitada se mantiene visible en el pie de la pantalla inicial. Los formularios se desplazan al aparecer el teclado. Los estados de carga bloquean envíos repetidos y los errores se presentan en español. La comunidad conserva su identidad visual con tarjetas, filtros, navegación y estados vacíos revisados.

## Diagramas y notación
Las láminas se organizan por responsabilidad: dominio, datos, estado de comunidad, presentación, tema, componentes, autenticación, presentación del acceso y firmas de las pantallas. Se entregan fuentes PlantUML, SVG, PNG y un PDF vectorial.
Se usa notación UML 2.5.1: atributos nombre: Tipo, operaciones con parámetros y retorno, + público, - privado, # protegido; asociaciones continuas con navegabilidad y multiplicidad cuando corresponde; realización o herencia con triángulo hueco; dependencias discontinuas sin multiplicidad. Los estereotipos data class, Kotlin object y file documentan convenciones de Kotlin. file agrupa funciones de nivel superior, no representa una clase real del código.
No se añaden rombos si el código no demuestra un ciclo de vida compuesto. categoryId es una referencia documental String; no implica un atributo objeto IncidentCategory. Los miembros generados por Kotlin se documentan en CATALOGO-FIRMAS.md.
Los componentes del diagrama son agrupaciones lógicas dentro del mismo APK, no módulos Gradle independientes. Se diferencia el SDK incluido en el APK de los servicios remotos de Firebase.

## Sustentación de dos funcionalidades
Primera: autenticación con correo o Google, recuperación y cierre de sesión. Explicar AuthRepository, AuthViewModel, OAuth y huellas SHA.
Segunda: consultar y publicar novedades. Explicar categorías, listeners, validación, requestId estable, timestamps y reglas; mostrar el documento creado en Firestore.
Las dos funcionalidades requieren completar la configuración indicada en INICIO-FIREBASE.md y comprobarlas en un dispositivo con acceso al servicio. No se presentan como verificadas contra el backend real desde este entorno.

## Verificación y requisitos pendientes
Consultar VALIDACION.md para los resultados actuales. El archivo proporcionado no contiene clientes OAuth; el proveedor Google y las huellas se activan en Firebase Console antes de descargar el JSON actualizado. El entorno bloquea conexiones a Firebase y la descarga de su emulador. No se ha demostrado aún el flujo completo contra tu base real.
