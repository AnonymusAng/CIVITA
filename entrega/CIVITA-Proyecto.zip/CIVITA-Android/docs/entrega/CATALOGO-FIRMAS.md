# Catálogo de firmas Kotlin

Fuente: código principal de la versión actualizada. Los miembros de data class listados a continuación se generan por Kotlin; no son operaciones de negocio ni métodos de persistencia.

## IncidentCategory

Constructor público; sin retorno explícito en la notación UML:

    IncidentCategory(
        id: String,
        label: String,
        color: Color,
        defaultDurationHours: Long = 4
    )

Operaciones públicas generadas:

    component1(): String
    component2(): String
    component3(): Color
    component4(): Long
    copy(
        id: String = this.id,
        label: String = this.label,
        color: Color = this.color,
        defaultDurationHours: Long = this.defaultDurationHours
    ): IncidentCategory
    equals(other: Any?): Boolean
    hashCode(): Int
    toString(): String

## UrbanReport

Constructor público; sin retorno explícito en la notación UML:

    UrbanReport(
        id: String,
        title: String,
        categoryId: String,
        category: String,
        description: String,
        location: String,
        severity: Int,
        time: String,
        status: ReportStatus,
        confidence: Int,
        color: Color
    )

Operaciones públicas generadas:

    component1(): String
    component2(): String
    component3(): String
    component4(): String
    component5(): String
    component6(): String
    component7(): Int
    component8(): String
    component9(): ReportStatus
    component10(): Int
    component11(): Color
    copy(
        id: String = this.id,
        title: String = this.title,
        categoryId: String = this.categoryId,
        category: String = this.category,
        description: String = this.description,
        location: String = this.location,
        severity: Int = this.severity,
        time: String = this.time,
        status: ReportStatus = this.status,
        confidence: Int = this.confidence,
        color: Color = this.color
    ): UrbanReport
    equals(other: Any?): Boolean
    hashCode(): Int
    toString(): String

## AppConfig

Constructor público; sin retorno explícito en la notación UML:

    AppConfig(
        allowedMediaTypes: List<String>,
        maxEvidenceBytes: Long,
        maxEvidenceCount: Int,
        minRadiusMeters: Long,
        maxRadiusMeters: Long
    )

Operaciones públicas generadas:

    component1(): List<String>
    component2(): Long
    component3(): Int
    component4(): Long
    component5(): Long
    copy(
        allowedMediaTypes: List<String> = this.allowedMediaTypes,
        maxEvidenceBytes: Long = this.maxEvidenceBytes,
        maxEvidenceCount: Int = this.maxEvidenceCount,
        minRadiusMeters: Long = this.minRadiusMeters,
        maxRadiusMeters: Long = this.maxRadiusMeters
    ): AppConfig
    equals(other: Any?): Boolean
    hashCode(): Int
    toString(): String

## ReportDraft

Constructor público; sin retorno explícito en la notación UML:

    ReportDraft(
        categoryId: String,
        title: String,
        description: String,
        location: String,
        severity: Int
    )

Operaciones públicas generadas:

    component1(): String
    component2(): String
    component3(): String
    component4(): String
    component5(): Int
    copy(
        categoryId: String = this.categoryId,
        title: String = this.title,
        description: String = this.description,
        location: String = this.location,
        severity: Int = this.severity
    ): ReportDraft
    equals(other: Any?): Boolean
    hashCode(): Int
    toString(): String

## CivitaUiState

Constructor público; sin retorno explícito en la notación UML:

    CivitaUiState(
        loading: Boolean = true,
        categories: List<IncidentCategory> = emptyList(),
        reports: List<UrbanReport> = emptyList(),
        config: AppConfig? = null,
        uid: String? = null,
        selectedCategoryId: String? = null,
        fromCache: Boolean = false,
        error: String? = null,
        submitting: Boolean = false,
        publicationError: String? = null,
        publishedId: String? = null
    )

Operaciones públicas generadas:

    component1(): Boolean
    component2(): List<IncidentCategory>
    component3(): List<UrbanReport>
    component4(): AppConfig?
    component5(): String?
    component6(): String?
    component7(): Boolean
    component8(): String?
    component9(): Boolean
    component10(): String?
    component11(): String?
    copy(
        loading: Boolean = this.loading,
        categories: List<IncidentCategory> = this.categories,
        reports: List<UrbanReport> = this.reports,
        config: AppConfig? = this.config,
        uid: String? = this.uid,
        selectedCategoryId: String? = this.selectedCategoryId,
        fromCache: Boolean = this.fromCache,
        error: String? = this.error,
        submitting: Boolean = this.submitting,
        publicationError: String? = this.publicationError,
        publishedId: String? = this.publishedId
    ): CivitaUiState
    equals(other: Any?): Boolean
    hashCode(): Int
    toString(): String

## Operaciones declaradas y archivos

Firmas extraídas de las declaraciones del código principal. Las funciones UI y tema llevan @Composable. Las extensiones conservan su receptor y los parámetros por defecto.

### MainActivity.kt

    protected override fun onCreate(savedInstanceState: Bundle?): Unit

### data/FirebaseReportRepository.kt

    override suspend fun signIn() : String
    override suspend fun loadConfig() : AppConfig
    override fun observeCategories() : Flow<RepositorySnapshot<IncidentCategory>>
    override fun observeReports() : Flow<RepositorySnapshot<UrbanReport>>
    override suspend fun publishReport(draft: ReportDraft, requestId: String) : String
    private fun DocumentSnapshot.requiredString(field: String) : String
    private fun DocumentSnapshot.requiredLong(field: String) : Long
    private fun parseColor(value: String) : Color

### data/ReportRepository.kt

    suspend fun signIn() : String
    suspend fun loadConfig() : AppConfig
    fun observeCategories() : Flow<RepositorySnapshot<IncidentCategory>>
    fun observeReports() : Flow<RepositorySnapshot<UrbanReport>>
    suspend fun publishReport(draft: ReportDraft, requestId: String) : String

### model/Models.kt

    fun fromDocument(value: String) : ReportStatus
    fun validationError() : String?

### ui/CivitaApp.kt

    fun CivitaApp(): Unit

### ui/CivitaViewModel.kt

    fun reload(): Unit
    fun selectCategory(id: String?): Unit
    fun publish(draft: ReportDraft): Unit
    fun clearPublication(): Unit
    private fun message(error: Exception) : String
    override fun <T : ViewModel> create(modelClass: Class<T>) : T

### ui/components/CivitaComponents.kt

    fun CivitaBrand(modifier: Modifier = Modifier): Unit
    fun SectionTitle(title: String, subtitle: String? = null, action: String? = null): Unit
    fun StatusPill(status: ReportStatus): Unit
    fun ReportCard(report: UrbanReport, modifier: Modifier = Modifier): Unit

### ui/screens/AlertsScreen.kt

    fun AlertsScreen(state: CivitaUiState): Unit

### ui/screens/MapScreen.kt

    fun MapScreen(state: CivitaUiState, onCategory: (String?) -> Unit, onReport: () -> Unit): Unit
    private fun StylizedMap(modifier: Modifier = Modifier): Unit

### ui/screens/ProfileScreen.kt

    fun ProfileScreen(state: CivitaUiState, authState: AuthUiState, onLogout: () -> Unit): Unit

### ui/screens/ReportScreen.kt

    fun ReportScreen(state: CivitaUiState, onPublish: (ReportDraft) -> Unit, onDone: () -> Unit): Unit

### ui/theme/Theme.kt

    fun CivitaTheme(content: @Composable () -> Unit): Unit

## Enumerados y comportamiento estándar

CivitaDestination y ReportStatus heredan name: String y ordinal: Int; Kotlin genera entries: EnumEntries<T>, values(): Array<T> y valueOf(value: String): T. ReportStatus.Companion declara fromDocument(value: String): ReportStatus. Estos miembros no constituyen lógica de persistencia.

copy realiza una copia superficial. Las val no prueban inmutabilidad profunda. visibleReports es una propiedad calculada de CivitaUiState y no un miembro del constructor.


## Autenticación añadida en 1.0.742

AuthUiState(initializing: Boolean = true, uid: String? = null, displayName: String? = null, email: String? = null, busy: Boolean = false, error: String? = null, message: String? = null).
Sus siete propiedades generan component1(): Boolean, component2/3/4(): String?, component5(): Boolean, component6/7(): String?, copy(...) con esos mismos parámetros y retorno AuthUiState; equals(other: Any?): Boolean, hashCode(): Int y toString(): String.

AuthRepository(auth: FirebaseAuth): observeSession(): Flow<FirebaseUser?>; login(email: String, password: String): Unit, register(email: String, password: String): Unit, resetPassword(email: String): Unit, google(context: Context): Unit y clearGoogleSession(context: Context): Unit son suspend; logout(): Unit no es suspend.

AuthViewModel(repository: AuthRepository): state: StateFlow<AuthUiState>; email(email: String, password: String, register: Boolean): Unit; reset(email: String): Unit; google(context: Context): Unit; logout(context: Context): Unit; clearFeedback(): Unit. execute(action: suspend () -> Unit): Unit es privado.

AuthViewModel.Factory(repository: AuthRepository) realiza ViewModelProvider.Factory con create<T: ViewModel>(modelClass: Class<T>): T.

AuthValidation: validEmail(email: String): Boolean; error(email: String, password: String, register: Boolean): String?. authErrorMessage(error: Exception): String es función de nivel superior.

AuthScreen(state: AuthUiState, onEmail: (String, String, Boolean) -> Unit, onGoogle: () -> Unit, onReset: (String) -> Unit, onModeChange: () -> Unit): Unit es @Composable.

CivitaViewModel incorpora stopObserving(): Unit. CivitaComponents.kt incorpora EmptyState(title: String, description: String): Unit, @Composable. AppContainer expone authRepository: AuthRepository? además de repository: ReportRepository?.
