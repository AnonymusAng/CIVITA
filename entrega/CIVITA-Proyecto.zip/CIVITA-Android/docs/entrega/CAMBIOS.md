# Cambios · 1.0.742

- Firebase Auth: Google con Credential Manager, correo, registro, recuperación y logout.
- Eliminación del inicio de sesión anónimo automático; puerta de sesión real para comunidad.
- Nueva interfaz de acceso, firma en cursiva, icono de aplicación y estados vacíos.
- Contraseñas sin guardado en Bundle, backup deshabilitado, mensajes en español y tiempos de espera.
- Cancelación de listeners al salir del área autenticada y recarga al regresar.
- Perfil basado en usuario autenticado, sin textos de desarrollo o métricas simuladas.
- Diagramas reorganizados con las clases y componentes de la nueva autenticación.
- Documentación descargable y huellas del APK para configurar Firebase.
