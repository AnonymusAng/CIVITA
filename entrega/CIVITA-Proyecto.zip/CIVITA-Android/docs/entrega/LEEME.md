# CIVITA · Descargas de la versión 1.0.742

CIVITA-Proyecto.zip contiene el proyecto Android y su documentación actualizada.
CIVITA-Documentacion.zip contiene diagramas PDF/PNG/SVG/PlantUML y documentos de activación, firmas y validación.
CIVITA-v1.0.742-debug.apk es el APK firmado de prueba.
Abre el PDF para visualizar diagramas sin depender del visor HTML. Los SVG permiten ampliar sin perder calidad; los PNG se abren como imágenes convencionales.
La configuración Google requiere un nuevo google-services.json tras habilitar proveedor y SHA; consulta INICIO-FIREBASE.md.
El archivo original del usuario se conserva sin alteraciones.
