# Verificación · CIVITA 1.0.742

## Compilación y análisis
Comando: python /workspace/civita-tools/build.py :app:testDebugUnitTest :app:assembleDebug :app:lintDebug.
La aplicación compila con el google-services.json suministrado y el plugin genera los recursos Firebase.
20 pruebas unitarias pasan: 7 de ReportDraft, 8 de CivitaViewModel y 5 de AuthValidation. Sin fallos, errores ni pruebas deshabilitadas.
Las pruebas nuevas verifican que un timeout termina el estado de carga/publicación y que un reintento conserva el ID original. Las pruebas existentes cubren validación, carga remota con repositorio de prueba, filtros, doble envío, caché y reintentos.
Android Lint: 0 errores. Las advertencias restantes se refieren a dos versiones más recientes de coroutines, dos búsquedas opcionales de recursos OAuth, la recomendación de dataExtractionRules en Android moderno y una sugerencia KTX. No se han deshabilitado pruebas para obtener este resultado.
El APK debug tiene versión 1.0.742, minSdk 26 y la firma se verifica con apksigner. Las huellas están en INICIO-FIREBASE.md.

## Interfaz y emulador Android
APK instalado y ejecutado en el emulador software CivitaLite, Android 8/API 26, pantalla 720×1440. Se comprobó la pantalla de acceso y la firma By: Joan Erazo v.10742 en cursiva. Se comprobaron el cambio a registro con confirmación de contraseña, el rechazo de un correo vacío, el aviso de configuración OAuth al pulsar Google y la validación previa de recuperación. No se enviaron correos de prueba ni se crearon cuentas remotas. El formulario permite desplazamiento. Las capturas actuales se entregan por separado; no son imágenes generadas.
Este emulador no incluye Google Play Services. No se han creado cuentas ficticias en el Firebase del usuario ni se presentan datos locales como datos remotos reales.

## Firebase real: pendiente
El JSON entregado contiene cero clientes OAuth. La implementación Google requiere habilitar proveedor Google, correo de soporte y huellas SHA; después descargar de nuevo google-services.json y recompilar. También hay que habilitar Correo/Contraseña y aplicar reglas compatibles.
Una comprobación HTTPS al servicio identitytoolkit.googleapis.com devuelve HTTP 403 del proxy de este entorno. No se pudo comprobar acceso, registro, correo de recuperación ni lectura/escritura de Firestore contra el proyecto real.
Las 12 pruebas de reglas Firestore incluidas se intentaron con demo-civita, pero la descarga oficial del emulador desde storage.googleapis.com fue denegada. Se registran como NO EJECUTADAS, no como aprobadas. Ver firebase-reglas-final.log.
No se han desplegado reglas ni alterado documentos remotos desde este entorno.

## Entrega y descargas
Se incluyen fuentes Android, documentación y UML en PDF vectorial A3, PNG, SVG y PlantUML. Los ZIP se comprueban con testzip y se mantienen por debajo de 40 MB. El proyecto original del ZIP del usuario se conserva separado sin modificaciones.
