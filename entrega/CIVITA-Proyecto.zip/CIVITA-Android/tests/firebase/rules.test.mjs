import { readFile } from 'node:fs/promises';
import { before, after, beforeEach, test } from 'node:test';
import assert from 'node:assert/strict';
import { initializeTestEnvironment, assertSucceeds, assertFails } from '@firebase/rules-unit-testing';
import { doc, setDoc, getDoc, updateDoc, deleteDoc, serverTimestamp, collection, query, orderBy, getDocs, runTransaction } from 'firebase/firestore';

let env;
const uid = 'ciudadano-a';
const valid = () => ({creatorId: uid, categoryId: 'movilidad', categoryName: 'Movilidad', categoryColor: '#1976D2',
  title: 'Semáforo averiado', description: 'El semáforo no cambia en la intersección.',
  locationReference: 'Carrera 6 con calle 8', severity: 2, status: 'review', confidence: 0,
  createdAt: serverTimestamp(), updatedAt: serverTimestamp()});
const db = () => env.authenticatedContext(uid).firestore();

before(async () => {
  env = await initializeTestEnvironment({projectId: 'demo-civita', firestore: {
    host: '127.0.0.1', port: 8080, rules: await readFile(new URL('../../firestore.rules', import.meta.url), 'utf8'),
  }});
});
after(async () => { await env?.cleanup(); });
beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async c => {
    await setDoc(doc(c.firestore(), 'categories/movilidad'), {active: true, name: 'Movilidad', color: '#1976D2', defaultDurationHours: 4});
    await setDoc(doc(c.firestore(), 'categories/inactiva'), {active: false, name: 'Inactiva', color: '#000000', defaultDurationHours: 4});
    await setDoc(doc(c.firestore(), 'appConfig/public'), {allowedMediaTypes: ['image/jpeg','image/png','video/mp4'], maxEvidenceBytes: 10485760, maxEvidenceCount: 3, minRadiusMeters: 250, maxRadiusMeters: 15000});
  });
});

test('permite leer configuración y categorías a una sesión autenticada', async () => {
  await assertSucceeds(getDoc(doc(db(), 'appConfig/public')));
  await assertSucceeds(getDoc(doc(db(), 'categories/movilidad')));
});
test('rechaza lectura y escritura sin autenticación', async () => {
  const guest = env.unauthenticatedContext().firestore();
  await assertFails(getDoc(doc(guest, 'appConfig/public')));
  await assertFails(setDoc(doc(guest, 'reports/r1'), valid()));
});
test('crea reporte y recupera contenido persistido y timestamps', async () => {
  await assertSucceeds(setDoc(doc(db(), 'reports/r1'), valid()));
  const snapshot = await assertSucceeds(getDoc(doc(db(), 'reports/r1')));
  assert.equal(snapshot.data().creatorId, uid);
  assert.equal(snapshot.data().severity, 2);
  assert.equal(typeof snapshot.data().createdAt.toMillis(), 'number');
});
test('consulta ordenada por createdAt devuelve los reportes', async () => {
  await assertSucceeds(setDoc(doc(db(), 'reports/r1'), valid()));
  const result = await assertSucceeds(getDocs(query(collection(db(), 'reports'), orderBy('createdAt', 'desc'))));
  assert.equal(result.size, 1);
});
test('transacción idempotente no duplica ni actualiza el reporte al reintentar', async () => {
  const firestore = db(); const ref = doc(firestore, 'reports/r1');
  const publish = () => runTransaction(firestore, async tx => {
    const existing = await tx.get(ref);
    if (!existing.exists()) tx.set(ref, valid());
    return ref.id;
  });
  assert.equal(await assertSucceeds(publish()), 'r1');
  const first = (await getDoc(ref)).data().createdAt.toMillis();
  assert.equal(await assertSucceeds(publish()), 'r1');
  assert.equal((await getDoc(ref)).data().createdAt.toMillis(), first);
  assert.equal((await getDocs(collection(firestore, 'reports'))).size, 1);
});
test('rechaza suplantación del autor', async () => {
  await assertFails(setDoc(doc(db(), 'reports/r1'), {...valid(), creatorId: 'otra-persona'}));
});
test('rechaza categorías ausentes, inactivas y nombres falsificados', async () => {
  await assertFails(setDoc(doc(db(), 'reports/r1'), {...valid(), categoryId: 'ausente'}));
  await assertFails(setDoc(doc(db(), 'reports/r2'), {...valid(), categoryId: 'inactiva', categoryName: 'Inactiva', categoryColor: '#000000'}));
  await assertFails(setDoc(doc(db(), 'reports/r3'), {...valid(), categoryName: 'Inventada'}));
});
test('rechaza gravedad inválida y números no enteros', async () => {
  for (const severity of [0, 4, 1.5]) await assertFails(setDoc(doc(db(), 'reports/r'+severity), {...valid(), severity}));
});
test('rechaza textos inválidos, campos extra y timestamps del cliente', async () => {
  await assertFails(setDoc(doc(db(), 'reports/r1'), {...valid(), title: ''}));
  await assertFails(setDoc(doc(db(), 'reports/blank'), {...valid(), title: '     '}));
  await assertFails(setDoc(doc(db(), 'reports/r2'), {...valid(), description: 'a'.repeat(2001)}));
  await assertFails(setDoc(doc(db(), 'reports/r3'), {...valid(), administrator: true}));
  await assertFails(setDoc(doc(db(), 'reports/r4'), {...valid(), createdAt: new Date(0)}));
});
test('no permite inventar confianza ni verificar un reporte al crearlo', async () => {
  await assertFails(setDoc(doc(db(), 'reports/r1'), {...valid(), confidence: 100}));
  await assertFails(setDoc(doc(db(), 'reports/r2'), {...valid(), status: 'verified'}));
});
test('rechaza actualizaciones y borrado desde el cliente', async () => {
  await assertSucceeds(setDoc(doc(db(), 'reports/r1'), valid()));
  await assertFails(updateDoc(doc(db(), 'reports/r1'), {confidence: 100}));
  await assertFails(deleteDoc(doc(db(), 'reports/r1')));
});
test('protege configuración, categorías y colecciones no habilitadas', async () => {
  await assertFails(setDoc(doc(db(), 'appConfig/public'), {maxEvidenceCount: 1000}));
  await assertFails(setDoc(doc(db(), 'categories/nueva'), {active: true}));
  await assertFails(setDoc(doc(db(), 'users/admin'), {role: 'admin'}));
});
